package testapp;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.junit.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.server.handler.FindElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.Verify;
import com.thoughtworks.selenium.condition.Presence;
public class opitiiiii {
	WebDriver driver;
	@Before
	public void openBr() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\SELENIUM\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://193.178.152.130:8090/cases");
	}
	 @Test
	public void createStep() {
		 WebDriverWait wait= new WebDriverWait(driver, 8000);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("button.button.new-test-case-button.blue.right")));
			WebElement newCase=driver.findElement(By.cssSelector("button.button.new-test-case-button.blue.right"));
			newCase.click();
			wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("select.dropdown.full-width.test-case-type")));
			Select dropdown=new Select(driver.findElement(By.cssSelector("select.dropdown.full-width.test-case-type")));
			dropdown.selectByValue("FUNC");
			WebElement nameCase=driver.findElement(By.cssSelector("input.text-input.full-width.test-case-name"));
			nameCase.sendKeys("Name_testCase");
			WebElement descriptionCase=driver.findElement(By.cssSelector("textarea.text-area.full-width.test-case-description"));
			descriptionCase.sendKeys("Some entered description.");
			String multiselectList=(driver.findElement(By.cssSelector("div.droppable-wrapper.left-selector-container>div.multiselect-list>div.list-item"))).getAttribute("data-reactid");
			driver.findElement(By.xpath("//div[contains(@class,'droppable-wrapper') and contains(@class,'left-selector-container')]/div[@class='multiselect-list']/div[@*='.0.1.1.0.0.2.0.3.0.0.1.0.0.0.$835.0.0']"));
	 } 

}
